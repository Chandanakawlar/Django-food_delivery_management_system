# forms.py
from django import forms
from app1.models import Food1, Restaurant, CustomUser
from django.contrib.auth.forms import UserCreationForm


class FoodForm(forms.ModelForm):
    class Meta:
        model = Food1
        fields = ['foodID', 'foodName1', 'foodDes1', 'foodPrice', 'RestId']

class RegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'password1', 'password2']

class LoginForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)


