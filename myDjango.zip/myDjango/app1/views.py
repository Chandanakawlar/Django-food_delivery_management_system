from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from app1.models import Restaurant, Food1, Order, CustomUser
from app1.forms import FoodForm, RegistrationForm, LoginForm
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
# Create your views here.

def adminhome(request):
    return render(request, 'adminhome.html')
    
def restaurant_list(request):
    rest = Restaurant.objects.all()
    return render(request, 'restauranthome.html', {'rest': rest})

def addrest(request):
    return render(request, 'addrestaurant.html')

def validateadd(request):
    if request.method=='POST':
        rest_id=request.POST["rid"]
        rest_name=request.POST["rname"]
        rest_type=request.POST["rtype"]
        rest_address=request.POST["raddress"]
        res=Restaurant.objects.all()
        b=False
        for r in res:
            if r.restID==rest_id:
                b=True
                # return HttpResponse("Student already registered!!")
                return render(request, "restadd_resp.html", {"b":b})                  
        r1=Restaurant(restID=rest_id, restName=rest_name, restType=rest_type, restAddress=rest_address)
        r1.save()
        # return HttpResponse("Student registration successfull!!")
        return render(request, "restadd_resp.html", {"b":b})

def deleterest(request):
    return render(request, "restid_del.html")

def validaterestdelete(request):
    if request.method == 'POST':
        rest_id = request.POST["rid"]
        try:
            restaurant = Restaurant.objects.get(restID=rest_id)
            restaurant.delete()
            b = True
            message = "Restaurant deleted successfully!"
        except Restaurant.DoesNotExist:
            b = False
            message = "Restaurant not registered!"
        return render(request, "restdelete_resp.html", {"b": b, "message": message})

def userhomepage(request):
    return render(request, 'userhome.html')

def user_rest_list(request):
    rest = Restaurant.objects.all()
    return render(request, 'userrest_display.html', {'rest': rest})

def add_food(request, restaurant_id):
    restaurant = get_object_or_404(Restaurant, pk=restaurant_id)

    if request.method == 'POST':
        form = FoodForm(request.POST)
        if form.is_valid():
            food = form.save(commit=False)
            food.RestId = restaurant  # Associate the food item with the selected restaurant
            food.save()  # Save the food item to the Food1 table
            return HttpResponse("Item added successfully!!")
    else:
        form = FoodForm()
    return render(request, 'add_food.html', {'form': form, 'restaurant': restaurant})

def restaurant_food_list(request, restaurant_id):
    # Retrieve the restaurant and its associated food items
    restaurant = get_object_or_404(Restaurant, pk=restaurant_id)
    foods = Food1.objects.filter(RestId=restaurant)  # Get all food items for the restaurant   
    # Render the template with the restaurant and food items
    return render(request, 'restaurant_food_list.html', {'restaurant': restaurant, 'foods': foods})

def delete_food(request, restaurant_id, food_id):
    food = get_object_or_404(Food1, pk=food_id, RestId=restaurant_id)
    if request.method == 'POST':
        food.delete()
        return redirect('restaurant_food_list', restaurant_id=restaurant_id)
    return render(request, 'confirm_delete.html', {'food': food, 'restaurant': restaurant})

def edit_food_price(request, restaurant_id, food_id):
    # Retrieve the specific food item and restaurant
    restaurant = get_object_or_404(Restaurant, pk=restaurant_id)
    food = get_object_or_404(Food1, pk=food_id, RestId=restaurant)
    
    if request.method == 'POST':
        form = FoodPriceForm(request.POST, instance=food)
        if form.is_valid():
            form.save()  # Save updates to the food item
            return redirect('restaurant_food_list', restaurant_id=restaurant_id)
    else:
        form = FoodPriceForm(instance=food)

    return render(request, 'edit_food_price.html', {'form': form, 'restaurant': restaurant, 'food': food})

# def user_menu(request, restaurant_id):
#     restaurant = get_object_or_404(Restaurant, pk=restaurant_id)
#     f = Food1.objects.filter(RestId=restaurant)
#     return render(request, 'user_food_list.html', {'restaurant': restaurant, 'f': f})

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, username)
            return redirect('userhome')
    else:
        form = RegistrationForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                auth_login(request, user)
                return redirect('userhome')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})

from django.shortcuts import render, get_object_or_404
from .models import Order

@login_required
def order_confirmation(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)

    return render(request, 'order_confirmation.html', {
        'order': order,
        'food_items': order.food_items.all(),
        'total_price': sum(item.foodPrice for item in order.food_items.all())
    })


@login_required
def checkout(request):
    if request.method == 'POST':
        address = request.POST.get('address')
        food_id = request.POST.get('food_id')
        order = Order.objects.create(
            address=address,
            food_id=food_id,
            user=request.user
        )
        return render(request, 'order_confirmation.html', {'order': order})
    return render(request, 'checkout.html')

def user_menu(request, restaurant_id):
    restaurant = get_object_or_404(Restaurant, pk=restaurant_id)
    f = Food1.objects.filter(RestId=restaurant)
    if request.method == 'POST':
        selected_foods = request.POST.getlist('selected_foods')
        food_items = Food1.objects.filter(foodID__in=selected_foods)

        # Create the order
        order = Order.objects.create(
            user=request.user,
            address=request.user.profile.address,  # Assuming the user has a profile with an address
            order_date=timezone.now()
        )
        
        # Add selected food items to the order
        order.food_items.set(food_items)
        order.save()

        return redirect('order_confirmation', order_id=order.id)

    return render(request, 'user_food_list.html', {'f': f, 'restaurant_id': restaurant_id})