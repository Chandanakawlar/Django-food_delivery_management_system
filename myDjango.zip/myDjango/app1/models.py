from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractUser

# Create your models here.
class Restaurant(models.Model):
    restID = models.AutoField(primary_key=True)
    restName = models.CharField(max_length=100)
    restType = models.CharField(max_length=50)
    restAddress = models.TextField()
    def __str__(self):
        return self.restName

class Food1(models.Model):
    foodID=models.CharField(max_length=10, primary_key=True)
    foodName1=models.CharField(max_length=100)
    foodDes1=models.CharField(max_length=100)
    foodPrice=models.DecimalField(max_digits=8, decimal_places=2)
    RestId=models.ForeignKey(Restaurant,on_delete=models.CASCADE,null=True)
    def __str__(self):
        return self.foodName1

class Food(models.Model):
    foodId=models.AutoField(primary_key=True)
    foodName=models.CharField(max_length=100)
    foodDes=models.CharField(max_length=100)
    def __str__(self):
        return self.foodName

class CustomUser(AbstractUser):
    username=models.CharField(max_length=100)
    date_joined = models.DateTimeField(default=timezone.now)
    last_logged_in = models.DateTimeField(null=True, blank=True)    
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='customuser_set',  # Add a related_name to avoid clashes
        blank=True,
        help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.',
        verbose_name='groups',
    )    
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='customuser_set',  # Add a related_name to avoid clashes
        blank=True,
        help_text='Specific permissions for this user.',
        verbose_name='user permissions',
    )
    def __str__(self):
        return self.username

class Order(models.Model):
    order_id = models.AutoField(primary_key=True)
    address = models.CharField(max_length=255)
    food_id = models.ForeignKey(Food1, on_delete=models.CASCADE, null=True)  # You might want to link this with a Food model instead
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='orders', null=True)
    order_date = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return f"Order {self.order_id} by {self.user.username}"