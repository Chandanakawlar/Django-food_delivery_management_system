"""
URL configuration for proj project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from app1.views import register, login_view, checkout, adminhome, restaurant_list, add_food, delete_food, edit_food_price, restaurant_food_list, validateadd, addrest,  validaterestdelete, deleterest,  userhomepage, user_rest_list, user_menu

urlpatterns = [
    path('admin/', admin.site.urls),
    path('adminhome/', adminhome),
    path('restdisplay/', restaurant_list),
    path('addrest/', addrest),
    path('validateadd/', validateadd, name='validate'),
    path('deleterest/', deleterest),
    path('validaterestdelete/',validaterestdelete, name='validaterestdelete'),
    path('userhome/', userhomepage),
    path('userrestdisplay/', user_rest_list),
    path('usermenu/<int:restaurant_id>/f/', user_menu, name='user_menu'),
    path('add_food/<int:restaurant_id>/', add_food, name='add_food'),
    path('restaurant/<int:restaurant_id>/foods/', restaurant_food_list, name='restaurant_food_list'),
    path('restaurant/<int:restaurant_id>/foods/delete/<str:food_id>/', delete_food, name='delete_food'),
    path('restaurant/<int:restaurant_id>/foods/edit/<str:food_id>/', edit_food_price, name='edit_food_price'),
    path('register/', register, name='register'),
    path('login/', login_view, name='login'),
    path('checkout/', checkout, name='checkout'),
]
